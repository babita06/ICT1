
<!DOCTYPE html>
<html>
<head>
<title>COMPETENT WORKS</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/gothenburg-1094950_1920.jpg');"> 
  <div class="wrapper">
    <div id="pageintro" class="hoc clear"> 
      <article>
        <h2 class="heading">Welcome To Competent Works</h2>
        <p>End to your water problems</p>
        <footer><a class="btn" href="#">SINCE 2001</a></footer>
      </article>
      
    </div>
  </div>
  <div class="wrapper row1">
    <header id="header" class="hoc clear">
      <nav id="mainav" class="fl_right">
        <ul class="clear">
          <li class="active"><a href="index.html">Home</a></li>
            <li class="active"><a href="AboutUs.html">About Us</a></li>
            <li class="active"><a href="form1.php">Contact Us</a></li>
            <li class="active"><a href="OurServices.html">Our Services</a></li>
            <li class="active"><a href="OurProjects.html">Our Projects</a></li>
                </ul>

      </nav>
    </header>
  </div>
</div>
<h2>Write A Comment</h2>
        <form action="thankyou.php" method="post">
          <div class="one_third first">
            <label for="name">Name <span>*</span></label>
            <input type="text" name="Name" id="Name" value="" size="22" required>
          </div>
          <div class="one_third first">
            <label for="email">Mail <span>*</span></label>
            <input type="email" name="Email" id="Email" value="" size="22" required>
          </div>
          <div class="one_third first">
            <label for="subject">Subject</label>
              <input type="Subject" name="Subject" required>
            
            <div class="one_third first">
                <label for="Message">Message</label>
                <input type=textarea rows="40" cols="50" name="Message">
          <div><br>
              
            <input type="submit" name="submit" value="Submit Form">
            &nbsp;
          </div>
            </div>

             
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3505.219490073146!2d77.4069106!3d28.5331217!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce8bf516160f3%3A0xcb06d0b3c38ce376!2sSupertech+Eco+Village+3!5e0!3m2!1sen!2sau!4v1518059889240" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
              
              <div class="wrapper row5">
    <h3>Follow Us On</h3>
<a href="#" t arget="_blank" class="up"><img src="images/demo/gallery/facebook-icon.png" alt=""></a>
<a href="#" target="_blank" class="up"><img src="images/demo/gallery/picasa-icon.png" alt=""></a>
<a href="#" target="_blank" class="up"><img src="images/demo/gallery/linkedin-icon.png" alt=""></a>
<a href="#" target="_blank" class="up"><img src="images/demo/gallery/youtube-icon.png" alt=""></a>
  <div id="copyright" class="hoc clear"> 
    
    <p class="fl_left">Copyright &copy; 2016 - All Rights Reserved - <a href="#">Domain Name</a></p>
   
  </div>
</div>

<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<script src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script src="layout/scripts/gmaps.js"></script>
</body>
</html>
            
            
      <!-- ################################################################################################ -->
    
