<?php
 
include 'connection.php';
 error_reporting(0);
 $name = $_POST['Name'];
  
if(!$_POST['submit']){
	// you can remove this echo code and add alert using JS or use required tag in your input feilds.
	echo "All feilds must be filled";
  }

else {
$sql = "DELETE from contact WHERE Name='$name'";
if (mysqli_query($conn, $sql)) {
    echo "<h1><center> record deleted successfully</center></h1>";
} 
    else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

}
?>

<html>
<head>
<title>Delte Data</title>
</head>

<body>
   
	<h2>Delete Data</h2>
		<form action="delete.php" method="POST">
			Name: <input type="text" name="Name" value="" required><br><br>
	<br>
            <input type="submit" name="submit" value="Submit"></form>
</body>

<!--
	Similarly you can make delete and updates pages with little changes in sql query and here and there. If you need to learn those too
	please check my youtube channel NOSGENE as i am running a full stack web development course there right now.
 -->

 <!--
      ENCODED BY RAMEEZ SAFDAR / For more web and other programmings check out my channel nosgene https://www.youtube.com/channel/UCYbUaMVWujooISm4m7NDIeg
 -->
</html>