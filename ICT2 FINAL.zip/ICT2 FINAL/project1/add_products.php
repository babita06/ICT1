<?php
 
include 'connection.php';
 error_reporting(0);
  $dd = $_POST['Product_ID'];
  $name = $_POST['Name'];
  $discrip = $_POST['Product Discription'];
  $qt = $_POST['Quantity'];
  
if(!$_POST['submit']){
	echo "All feilds must be filled";
  }

else {
$sql="INSERT INTO products(Product_ID,Name,Discription,Quantity) VALUES ('$dd','$name','$discrip','$qt')";
if (mysqli_query($conn, $sql)) {
    echo "<h1><center>New record created successfully</center></h1>";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}
?>

<html>
<head>
<title>Add Data</title>
</head>

<body>
   
	<h2>Add Updates from this menu</h2>
		<form action="add_products.php" method="POST">
			Product_ID: <input type="text" name="ID" value="" required><br><br>
			Product Name: <input type="text" name="Name" value="" required><br><br>
			Product Discription: <input type=textarea rows="40" cols="50" name="Message">
            Quantity:<input type="Quantity" name="Quantity" required><br>
	<br>
            <input type="submit" name="submit" value="Submit"></form>
</body>


</html>