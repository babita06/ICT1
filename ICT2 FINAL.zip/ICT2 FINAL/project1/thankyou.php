
<?php
 
require 'connection.php';
$conn    = Connect();
$name    = $conn->real_escape_string($_POST['Name']);
$email   = $conn->real_escape_string($_POST['Email']);
$subj    = $conn->real_escape_string($_POST['Subject']);
$message = $conn->real_escape_string($_POST['Message']);
$query   = "INSERT into contact (Name,Email,Subject,Message) VALUES('" . $name . "','" . $email . "','" . $subj . "','" . $message . "')";
$success = $conn->query($query);
 
if (!$success) {
    die("Couldn't enter data: ".$conn->error);
 
}
 
echo "Thank You For Contacting Us <br>";
 
$conn->close();
 
?>